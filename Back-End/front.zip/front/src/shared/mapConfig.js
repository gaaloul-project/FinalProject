export const bootstrapURLKeys = {
  key: 'AIzaSyBUvk0z5VicbqlUh-7cccmJypbk72uxNQU',
  v: '3.36',
};
